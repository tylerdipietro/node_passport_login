module.exports = {
    MongoURI: 'mongodb+srv://tdipietro87:tdipietro87@tmcluster-pbtwu.mongodb.net/test?retryWrites=true'
}