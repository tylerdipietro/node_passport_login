dhtmlxScheduler v.5.1.6 Stardard

This software is covered by GPL license. You also can obtain Commercial or Enterprise license to use it in non-GPL project - please contact sales@dhtmlx.com. Usage without proper license is prohibited.

(c) Dinamenta, UAB.


Useful links
-------------

- Online  documentation
	https://docs.dhtmlx.com/scheduler/
- Downloadable documentation
	CHM version
		https://docs.dhtmlx.com/chm/scheduler.chm.zip
	HTML version
		https://dhtmlx.com/regular/dhtmlxScheduler_docs_html.zip
- Support forum
	https://forum.dhtmlx.com/c/scheduler-all/scheduler
- Skin builder
	https://dhtmlx.com/docs/products/dhtmlxScheduler/skinBuilder/index.shtml


Other editions
--------------

- MVC.Net edition
	http://scheduler-net.com
- Scheduler for mobile devices
	https://dhtmlx.com/x/download/regular/dhtmlxScheduler_mobile.zip